<?php

namespace Pterodactyl\Exceptions\Service\Allocation;

use Pterodactyl\Exceptions\PterodactylException;

class AllocationDoesNotBelongToServerException extends PterodactylException
{
}
